package com.abnamro.bankapp.service;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDate;

@Service
public class UpdateAssignedProductStatus {
    @Autowired
    private CustomerOwnedProductsRepository repo;
    public int updateStatus( int customerId,  CustomerOwnedProducts c1) {
        int productId=c1.getProductId();
        boolean a = c1.isStatus();
        LocalDate d=c1.getEndDate();
        System.out.println(a);
        System.out.println("hi1111111111111111");
        int b = repo.updateStatus(a, productId, customerId);

        return b;

    }
}
