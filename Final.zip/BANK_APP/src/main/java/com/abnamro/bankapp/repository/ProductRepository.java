package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Integer> {
}
