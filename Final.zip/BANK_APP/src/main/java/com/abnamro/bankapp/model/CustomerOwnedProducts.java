package com.abnamro.bankapp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import javax.persistence.*;
import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data

@Table(name = "CustomerRequestedProducts")
public class CustomerOwnedProducts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cpId;
    private int customerId;
    private int productID;
    private String customerName;
    private boolean status;
    private String productName;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate;


    @ManyToOne(cascade = CascadeType.ALL, targetEntity = Product.class)
    //@JoinColumn(name = "P_id", referencedColumnName = "productId")
    @Transient
    private Product product;


}
