package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import com.abnamro.bankapp.service.AssignProductService;
import com.abnamro.bankapp.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;


@RestController
@RequestMapping("/bank")
public class AssignProductController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;
    @Autowired
    private AssignProductService assignProductService;

    @Autowired
    private ProductRepository p;
    private Logger logger = LoggerFactory.getLogger(AssignProductController.class);


    @PutMapping("/assignProduct/{customerId}")

    public ResponseEntity<HttpStatus> assignProduct(@PathVariable Integer customerId, @RequestBody Customer customer) {
        //return assignProductService.assignProduct(customerId, customer);
        Customer customer1 = customerRepository.findById(customerId).get();
        int a = customer1.getAge();
        System.out.println(a);
        double b = customer1.getIncome();
        System.out.println(b);
        if ((a) > 30 && (b) > 3000.0) {
            System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");
            int productId;
            List<CustomerOwnedProducts> c1=customer.getCustomerOwnedProducts();
            int i;
          System.out.println(c1);
           // for (i=0;i<c1.size();i++) {
             //   CustomerOwnedProducts c= c1.get(i);
            for(CustomerOwnedProducts c : c1){
                System.out.println("printing   cccccc"+c);
                System.out.println("test1111");
                productId = c.getProductID();
                CustomerOwnedProducts c2 =null;
                try {
                    c2 = repo.findbyCustIdAndProductId(customerId,productId);
                    System.out.println(c2);
                }catch(NoSuchElementException x){
                    System.out.println(x);

                }
                if(c2==null) {
                    //logger.info("testing");
                    System.out.println("-----------------aaaaaaaa");
                    // List<CustomerOwnedProducts> cop=  customer.getCustomerOwnedProducts();
                    //  for(CustomerOwnedProducts cop1 : cop)

                   assignProductService.assignProductvalues(customerId, c);
                    //customerService.assignCustomerValues(customerId);

                    Customer customer2 = customerRepository.findById(customerId).get();
                    List<CustomerOwnedProducts> co  =new ArrayList<>(Arrays.asList(c));


                    customer1.setCustomerOwnedProducts(co);

                    customerRepository.save(customer2);
                    //return customer2;
                    //customer1.assignProduct1(customer);
                    //repo.save(customerOwnedProducts);
                    //return new ResponseEntity<>(HttpStatus.OK);
                } else{
                    return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            //logger.info("error");
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }



    @GetMapping("/getassignedProducts/{id}")
    public CustomerOwnedProducts getAssignedProducts(@PathVariable int id) {
        CustomerOwnedProducts c1 = repo.findById(id).get();
        return c1;
    }


}
