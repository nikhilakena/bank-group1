package com.abnamro.bankapp.controller;
import com.abnamro.bankapp.exception.ResourceNotFound;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;


@RestController
@RequestMapping("/bank")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private CustomerOwnedProductsRepository customerOwnedProductsRepository;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product) {

        return productService.saveProduct(product);

    }

    @GetMapping("/getProduct/{id}")
    public Product getProductById(@PathVariable Integer id) {

        return productService.getProductbyId(id);
    }


    @PutMapping("/deleteProduct/{productId}")
    public ResponseEntity<String> deleteProductbyId(@PathVariable Integer productId, @RequestBody Product product) throws ResourceNotFound {
        List<CustomerOwnedProducts> c = null;
        return productService.deleteProduct(productId, product);
    }

}