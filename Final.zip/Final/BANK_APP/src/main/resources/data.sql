/*
insert into product(productId,name,startDate,endDate,status) values (354,'SavingAccount','22/11/2019','22/11/2030',1);
insert into product(productId,name,startDate,endDate,status) values (355,'Fixed Deposit','21/01/2020','21/01/2050',1);
insert into product(productId,name,startDate,endDate,status) values (380,'CreditCard','20/09/2021','20/09/2025',1);
*/
/*
insert into customer values ('Thane Mumbai',28,50000,'Piyush');
insert into customer values ('Thane Mumbai',29,80000,'Aastha');
insert into customer values ('Thane Mumbai',45,750000,'Rahul');
insert into customer values ('Dehradun',56,750000,'Rohan');
insert into customer values ('154 Thane Mumbai',76,580000,'MJ');
insert into customer values ('206 Thane Mumbai',76,610000,'MJ');*/
/*
--insert into customer_product values (1,1);
--insert into customer_product values (1,2);
--insert into customer_product values (2,3);


*/



