package com.abnamro.bankapp.dto;

import lombok.Data;

@Data
public class ResponseDTO {

    private int customerId;
    private int productId;
    private String customerName;
    private String productName;
}
