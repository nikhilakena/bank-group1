package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.exception.ResourceNotFound;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import com.abnamro.bankapp.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;




        import com.abnamro.bankapp.exception.ResourceNotFound;
        import com.abnamro.bankapp.model.Customer;
        import com.abnamro.bankapp.model.CustomerOwnedProducts;
        import com.abnamro.bankapp.model.Product;
        import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
        import com.abnamro.bankapp.repository.CustomerRepository;
        import com.abnamro.bankapp.repository.ProductRepository;
        import com.abnamro.bankapp.service.AssignProductService;
        import com.abnamro.bankapp.service.CustomerService;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.HttpStatus;
        import org.springframework.http.ResponseEntity;
        import org.springframework.web.bind.annotation.*;

        import java.util.ArrayList;
        import java.util.Arrays;
        import java.util.List;
        import java.util.NoSuchElementException;


@RestController
@RequestMapping("/bank")
public class AssignProductSecondWayController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;
    @Autowired
    private AssignProductSecondWayService assignProductSecondWayService;

    @Autowired
    private ProductRepository p;
    private Logger logger = LoggerFactory.getLogger(AssignProductController.class);



    @PostMapping("/assignProduct")

    public ResponseEntity<String> assignProduct(@RequestBody CustomerOwnedProducts customerOwnedProducts) throws ResourceNotFound
    {
        return assignProductSecondWayService.assignProduct(customerOwnedProducts);
    }





}

