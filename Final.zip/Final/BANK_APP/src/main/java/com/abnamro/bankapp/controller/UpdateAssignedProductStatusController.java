package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.model.CustomerOwnedProducts;

import com.abnamro.bankapp.service.UpdateAssignedProductStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bank")
public class UpdateAssignedProductStatusController {
    @Autowired
    private UpdateAssignedProductStatusService updateAssignedProductStatus;

    @PutMapping("/updateStatus")

    public int updateStatus( @RequestBody CustomerOwnedProducts c1) {
        //  boolean a = c1.isStatus();
        int customerId=c1.getCustomerId();

        return updateAssignedProductStatus.updateStatus(customerId, c1);
    }
}
