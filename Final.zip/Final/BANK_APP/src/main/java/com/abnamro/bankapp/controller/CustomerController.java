package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.dto.UserRequest;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/bank")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/addCustomer")
    public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {

        return new ResponseEntity<>( customerService.saveCustomer(customer),HttpStatus.CREATED);
    }
    @GetMapping("/getCustomerByIncome")
    public ResponseEntity<List<Customer>> getTop5CustomerByIncome(){
        List<Customer> customerList= customerService.getTop5CustomerByIncome();
        return new ResponseEntity<>(customerList, HttpStatus.OK);
    }


    @GetMapping("/getCustomerById/{customerId}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable("customerId") int customerId)  {
        Customer customer= customerService.getCustomerById(customerId);
        return ResponseEntity.status(HttpStatus.OK).body(customer);

    }

    @GetMapping("/getCustomerByLocation/{location}")
    public ResponseEntity<List<Customer>> getCustomerByLocation(@PathVariable("location") String location)  {
        List<Customer> customers=customerService.getCustomerByLocation(location);
        return ResponseEntity.status(HttpStatus.OK).body(customers);
    }
}
