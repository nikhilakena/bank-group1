package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import org.hibernate.sql.Update;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

public interface CustomerOwnedProductsRepository extends JpaRepository<CustomerOwnedProducts, Integer> {

    @Modifying
    @Transactional
    @Query("update CustomerOwnedProducts c set c.status = ?1,c.endDate=?2  where c.productId= ?3 and c.customerId=?4")
    int updateStatus(boolean status, LocalDate d, int productId, int customerId);

    @Query("select t from CustomerOwnedProducts t where  t.productId =?1 and t.status=true")
    List<CustomerOwnedProducts> findByProductIdAndStatus(int productId);
    @Query(value = "select new com.abnamro.bankapp.model.CustomerOwnedProducts(t.customerId,t.productId,t.customerName,t.productName) from CustomerOwnedProducts t  where  t.customerId =?1")
   List<CustomerOwnedProducts> findByCustomerId(int customerId);
    @Query("select t from CustomerOwnedProducts t where  t.productId =?1")
    List<CustomerOwnedProducts> findByProductId(int productId);
    @Query("select t from CustomerOwnedProducts  t where t.customerId=?1 and t.productId=?2")
    CustomerOwnedProducts findbyCustIdAndProductId(int customerId, int productId);
}
