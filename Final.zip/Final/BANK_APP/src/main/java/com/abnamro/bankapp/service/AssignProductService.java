package com.abnamro.bankapp.service;

import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class AssignProductService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;

    public ResponseEntity<String> assignProduct(int customerId, Customer customer){

        Customer customer1 = customerRepository.findById(customerId).get();
        int a = customer1.getAge();
        System.out.println(a);
        double b = customer1.getIncome();
        System.out.println(b);
      //  Product product1 = productRepository.findById(productId).get();
        if ((a) > 30 && (b) > 10000.0) {

            int productId;
            List<CustomerOwnedProducts> c1=customer.getCustomerOwnedProducts();
            int i;
            String add="ProductId's";
            String assignedIds="Can't assign requested Products, as ProductId's";
            String deactivatedIds="Can't assign requested Products, as ProductId's";
            for (i=0;i<c1.size();i++) {
                CustomerOwnedProducts c= c1.get(i);
                productId = c.getProductId();
                Product product1 = productRepository.findById(productId).get();
           //    if( product1.isStatus()== true){
                CustomerOwnedProducts c2 =null;
                try {
                    c2 = repo.findbyCustIdAndProductId(customerId,productId);
                    System.out.println(c2);
                }catch(NoSuchElementException x){
                    System.out.println(x);

                }
                if(c2==null) {
                    //logger.info("testing");
                    if( product1.isStatus()== true) {
                        assignProductvalues(customerId, c);
                        Customer customer2 = customerRepository.findById(customerId).get();
                        List<CustomerOwnedProducts> co = new ArrayList<>(Arrays.asList(c));
                        customer1.setCustomerOwnedProducts(co);
                        customerRepository.save(customer2);

                       add=add+" "+productId ;
                    }else{
                        deactivatedIds=deactivatedIds+" "+productId;
                       // return new ResponseEntity<>("ProductId "+productId+" is deactivated",HttpStatus.NOT_FOUND);
                    }

                } else{

                    assignedIds=assignedIds+" "+productId;
                  //  int assignedId= productId;
                    //return new ResponseEntity<>("Product already assigned to customer",HttpStatus.ALREADY_REPORTED);
                }
            }
            return new ResponseEntity<>(add+" is/are assigned to customer."+'\n'
                    +assignedIds +" is/are already assigned to customer."+'\n'
                    +deactivatedIds +" is/are not active at this time.",HttpStatus.MULTI_STATUS);
        } else {
            //logger.info("error");
            return new ResponseEntity<>("Request not processed because customer not met the required criteria :"+'\n'+
                    "Customer Age should be greater than 30 and income should be more than 10000",HttpStatus.EXPECTATION_FAILED);

        }
    }
    public void assignProductvalues(Integer customerId, CustomerOwnedProducts c) {


        int productId = 0;
        int custId=0;

        productId = c.getProductId();

        custId=customerId;
        Product product1 = productRepository.findById(productId).get();
        Customer customer = customerRepository.findById(custId).get();
        // Product product1 = product.get();
        c.setProductName(product1.getName());
        c.setStartDate(LocalDate.now());
        c.setEndDate(product1.getEndDate());
        c.setStatus(product1.isStatus());
        //  c.setCustomers(customer);
        // c.setCustomerId(customer.getCustomerId());
        c.setCustomerName(customer.getName());
        c.setCustomerId(customer.getCustomerId());
        c.setProduct(product1);
        // customer.setCustomerOwnedProducts(Collections.singletonList(c));

        //  }
    }

}
