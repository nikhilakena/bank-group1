package com.abnamro.bankapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ControllerExceptionHandler {

    @ExceptionHandler(DataNotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ErrorResponse resourceNotFoundException(DataNotFoundException ex) {
        HttpStatus status= ex.getStatus()==null?HttpStatus.NOT_FOUND : ex.getStatus();
        ErrorResponse message = new ErrorResponse(ex.getMessage(),status.value());
        return message;
    }

    


}
