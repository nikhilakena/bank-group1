package com.abnamro.bankapp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Entity
@Data

@Table(name = "CustomerOwnedProducts")
public class CustomerOwnedProducts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cpId;
    private int customerId;
    private int productId;
    private String customerName;
    private boolean status;
    private String productName;
    @JsonFormat(pattern = "dd/MM/yyyy")
  // @CreationTimestamp
    private LocalDate startDate;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate;


    @ManyToOne(cascade = CascadeType.ALL, targetEntity = Product.class)
    //@JoinColumn(name = "P_id", referencedColumnName = "productId")
    @Transient
    private Product product;

    public CustomerOwnedProducts( int customerId, int productId, String customerName, String productName) {

        this.customerId = customerId;
        this.productId = productId;
        this.customerName = customerName;

        this.productName = productName;

    }
}
