package com.abnamro.bankapp.exception;

public class ResourceNotFound extends Exception{
    public ResourceNotFound(String s) {
        System.out.println(s);
    }
}
