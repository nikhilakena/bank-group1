package com.abnamro.bankapp.exception;

import org.springframework.http.HttpStatus;

public interface CustomException {
    HttpStatus getStatus();
}
