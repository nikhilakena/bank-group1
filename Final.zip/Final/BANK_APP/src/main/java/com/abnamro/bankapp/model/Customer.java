package com.abnamro.bankapp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor()
@NoArgsConstructor
@Entity
@Table(name = "Customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int customerId;
    @Valid
    @NotNull(message = "Customer name shouldn't be null")
    private String name;
    @Valid
    @NotNull
    @Email(message = "invalid email address")
    private String email;
    @Valid
    @NotNull
    @Pattern(regexp = "^\\d{10}$",message = "invalid mobile number entered ")
    private String mobileNumber;
    @Min(18)
    @Max(60)
    @Valid
    @NotNull
    private int age;
   // @Valid
    @NotNull(message="Income field is mandatory")
    private double income;
    @Valid
    @NotNull(message = "Address can't be empty")
    private String address;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = CustomerOwnedProducts.class)
    //@JoinColumn(name = "customer_id", referencedColumnName = "customerId")
   // @JsonIgnore
    private List<CustomerOwnedProducts> customerOwnedProducts;

    public Customer( String name, int age, int income, String address) {
        this.name = name;
        this.age = age;
        this.income = income;
        this.address = address;
    }
}



