package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.dto.ResponseDTO;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/bank")
public class CustomersAssignedToProductController {

    @Autowired
    CustomerOwnedProductsRepository customerOwnedProductsRepository;
    @GetMapping("/getCustomersByProductId/{productId}")
    public List<ResponseDTO> getCustomersByProductId(@PathVariable int productId) {
        List<ResponseDTO> responseDTOList = new ArrayList<>();
        List<CustomerOwnedProducts> cop = customerOwnedProductsRepository.findByProductId(productId);
        for (CustomerOwnedProducts cop1 : cop) {
            ResponseDTO responseDTO = new ResponseDTO();
            responseDTO.setCustomerId(cop1.getCustomerId());
            responseDTO.setProductId(cop1.getProductId());
            responseDTO.setCustomerName(cop1.getCustomerName());
            responseDTO.setProductName(cop1.getProductName());

            responseDTOList.add(responseDTO);
        }
        return responseDTOList;
    }
}
