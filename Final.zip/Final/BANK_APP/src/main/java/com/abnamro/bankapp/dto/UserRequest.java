package com.abnamro.bankapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.*;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class UserRequest {
    @Valid
    @NotNull(message = "Customer name shouldn't be null")
    private String name;
    @Min(18)
    @Max(60)
    @Valid
    private int age;
    @NotNull
    @Valid
    private double income;
    @NotNull(message = "Address can't be empty")
    @Valid
    private String address;
    @Email(message = "invalid email address")
    @Valid
    private String email;
    @Pattern(regexp = "^\\d{10}$",message = "invalid mobile number entered ")
    @Valid
    private String mobileNumber;
}
