package com.abnamro.bankapp.service;

import com.abnamro.bankapp.constants.MessageConstants;
import com.abnamro.bankapp.dto.AssignProductDTO;
import com.abnamro.bankapp.dto.UserRequest;
import com.abnamro.bankapp.exception.DataNotFoundException;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgConfigPropertyType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;

    public Customer saveCustomer( Customer customer) {

        return customerRepository.save(customer);
    }




    public List<Customer> getTop5CustomerByIncome() {
        List<Customer> customerList= (List<Customer>) customerRepository.findAll();
        List<Customer> filteredCustomerList=customerList.stream().sorted(Comparator.comparingDouble(Customer :: getIncome).reversed())
                .limit(5).collect(Collectors.toList());
        return filteredCustomerList;
    }

    public Customer getCustomerById(int customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() -> new DataNotFoundException(MessageConstants.CUSTOMER_NOT_FOUND));
    }

    public List<Customer> getCustomerByLocation(String location) {
        List<Customer> customerList= customerRepository.findAll();
        List<Customer> filteredCustomerList= customerList.stream()
                .filter(customer->customer.getAddress().toLowerCase().contains(location.toLowerCase()))
                .collect(Collectors.toList());
        return filteredCustomerList;
    }

}




