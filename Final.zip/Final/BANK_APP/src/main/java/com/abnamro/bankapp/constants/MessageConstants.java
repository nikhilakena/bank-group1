package com.abnamro.bankapp.constants;

public class MessageConstants {

    private MessageConstants(){}

    public static final String CUSTOMER_NOT_FOUND="Customer does not exist";
}
