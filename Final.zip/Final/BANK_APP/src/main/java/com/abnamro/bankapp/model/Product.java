package com.abnamro.bankapp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Entity
public class Product {
    @Id

    private int productId;
    @Valid
    @NotNull(message = "Product name is mandatory")
    private String name;
    @Valid
    @NotNull(message="StartDate is mandatory")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate;
    @Valid
    @NotNull(message="EndDate is mandatory")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate;
    @Valid
    @NotNull(message="status must be true or false")
    //@Pattern(regexp = "^(true|false)$", message = "restartable field allowed input: true or false")

    private boolean status;


}

