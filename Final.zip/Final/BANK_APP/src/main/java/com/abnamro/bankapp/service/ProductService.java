package com.abnamro.bankapp.service;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerOwnedProductsRepository customerOwnedProductsRepository;

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public Product getProductbyId(Integer id) {
        return productRepository.findById(id).get();
    }


    public void deleteProductbyId(Integer id, Product product) {
        Product product1 = productRepository.findById(id).get();
        // return productRepository.save(product1);
        product1.setStatus(product.isStatus());
        product1.setEndDate(LocalDate.now());
        productRepository.save(product1);

    }

    public ResponseEntity<String> deleteProduct(int productId, Product product) {
        List<CustomerOwnedProducts> c = null;

        try {
            System.out.println("heloo11111111111");
            c = customerOwnedProductsRepository.findByProductIdAndStatus(productId);
        } catch (
                NoSuchElementException x) {
            System.out.println(x);
        }

        if (c.isEmpty()) {
            deleteProductbyId(productId, product);
            return new ResponseEntity<>("Soft delete done successfully",HttpStatus.ACCEPTED);

        } else {
            return new ResponseEntity<>("Product is used by the customers, so can't deactivate the product ",HttpStatus.CONFLICT);

        }

    }
}
