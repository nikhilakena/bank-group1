package com.abnamro.bankapp.exception;

import org.springframework.http.HttpStatus;

public class DataNotFoundException extends RuntimeException implements  CustomException{

    private HttpStatus status=HttpStatus.NOT_FOUND;

    public DataNotFoundException(){
        super();
    }

    public DataNotFoundException(String message,HttpStatus status){
        super(message);
        this.status=status;
    }

    public DataNotFoundException(String message){
        super(message);
    }

    public DataNotFoundException(String message,Throwable cause){
        super(message,cause);
    }

    public DataNotFoundException(Throwable cause){
        super(cause);
    }


    @Override
    public HttpStatus getStatus() {
        return status;
    }
}
