package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Product;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest(classes = BankAppApplication.class)
public class ProductRepositoryTest {


    @Autowired
    private ProductRepository p;
    @Test
    @Order(1)
    void createProduct(){
        Product product1 =getProduct();

        p.save(product1);
        Product found= p.findById(product1.getProductId()).get();
        assertEquals(product1.getProductId(),found.getProductId());
    }

    @Test
    @Order(2)
      void deleteProduct(){
    Product product1 =getProduct();
   // p.save(product1);
    product1.setStatus(false);
        p.save(product1);
    Product found= p.findById(product1.getProductId()).get();
    assertEquals(false,found.isStatus());
                 }
    private Product getProduct() {
        Product product = new Product();
        product.setProductId(11);
        product.setName("Credit");
        product.setEndDate(LocalDate.now());
        product.setStartDate(LocalDate.now());
        product.setStatus(true);
        return product;
    }
}
