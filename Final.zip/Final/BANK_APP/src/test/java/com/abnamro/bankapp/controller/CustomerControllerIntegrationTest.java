package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
/*import org.springframework.boot.test.web.server.LocalServerPort;*/
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class CustomerControllerIntegrationTest {
  //Getting port reference where applicationContext is running.
  @LocalServerPort
  private int port;

  private String baserUrl="http://localhost:";

  private static RestTemplate restTemplate;

  @Autowired
  private CustomerRepository customerRepository;

  @BeforeAll
  private static void init(){
    restTemplate=new RestTemplate();
  }

  @BeforeEach
  public void setUp(){
    baserUrl=baserUrl.concat(port+"/bank");
  }
  @Test
  public void getTop5CustomerByIncome() {
    List<Customer> customerList=restTemplate.getForObject(baserUrl+"/getCustomerByIncome", List.class);
    assertEquals(5,customerList.size());
  }

  @Test
  public void getCustomerById() {
    Customer customer=restTemplate.getForObject(baserUrl+"/getCustomerById/{id}",Customer.class,1);
    assertAll(
        ()->assertNotNull(customer),
        ()->assertEquals(1,customer.getCustomerId())
    );
  }

  @Test
  public void getCustomerByLocation()  {
    JsonNode customers=restTemplate.getForObject(baserUrl+"/getCustomerByLocation/{location}",JsonNode.class,"thane");
    ObjectMapper objectMapper = new ObjectMapper();
    List<Customer> customerList = objectMapper.convertValue(
        customers,
        new TypeReference<List<Customer>>(){}
    );
    assertTrue(customerList.get(0).getAddress().contains("Thane"));
  }
}