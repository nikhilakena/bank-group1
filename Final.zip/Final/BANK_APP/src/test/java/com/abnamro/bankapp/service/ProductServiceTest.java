package com.abnamro.bankapp.service;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.time.LocalDate;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
public class ProductServiceTest {
    @MockBean
   private ProductService productService;


    @Test
    void deleteProduct(){
        Product product1 =getProduct();
        productService.saveProduct(product1);
        product1.setStatus(false);
       productService.deleteProduct(11,product1);
        assertTrue(true);
       assertEquals(false,product1.isStatus());


    }

    private Product getProduct() {
        Product product = new Product();
        product.setProductId(11);
        product.setName("Credit");
        product.setEndDate(LocalDate.now());
        product.setStartDate(LocalDate.now());
        product.setStatus(true);
return product;
    }
}
