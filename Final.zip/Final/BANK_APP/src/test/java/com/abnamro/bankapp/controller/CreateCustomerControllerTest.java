package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Customer;

import static org.springframework.http.MediaType.APPLICATION_JSON;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.abnamro.bankapp.service.CustomerService;



@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
@AutoConfigureMockMvc
public class CreateCustomerControllerTest {
    @MockBean
    private CustomerController customerController;

    @Autowired
    private MockMvc mvc;
   @Test
    void testCreateCustomer() throws Exception {
Customer customer= getCustomer();
//customerController.addCustomer(customer);
     //  assertEquals(1,customer.getCustomerId());
//doNothing().when(customerController).addCustomer(customer);
       //assertEquals( new ResponseEntity<> (customerService.saveCustomer(customer), HttpStatus.CREATED),customerController.addCustomer(customer));
   mvc.perform(post("/bank/addCustomer").content(asJson(customer)).contentType(APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

    }

    private Customer getCustomer(){
        Customer customer= new Customer();
        customer.setCustomerId(1);
        customer.setName("Nikhil Teja Akena");
        customer.setIncome(20000);
        customer.setAge(23);
        customer.setEmail("nikhilakena@gmail.com");
        customer.setMobileNumber("9848113318");
        customer.setAddress("Khammam, Hyderbad");
        return customer;

    }
    private static String asJson(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
