package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.Product;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
@AutoConfigureMockMvc

public class ProductControllerTest {
    @MockBean
    ProductController productController;
    @Autowired
    private MockMvc mvc;
    private Customer customer;
    private Product product;


    @Test
    void testDeleteProduct() throws Exception {
        Product product = getProduct();
        mvc.perform(put("/bank/deleteProduct/" + product.getProductId()).content(asJson(product)).contentType(APPLICATION_JSON)).andExpect(status().isOk()).andReturn();


    }

    private Product getProduct() throws ParseException {
        Product product = new Product();
        product.setProductId(11);
        product.setName("Savings Account");
        //   DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //   product.setStartDate(LocalDate.now());
        // product.setEndDate(LocalDate.now());
        product.setStatus(true);
        return product;
    }

    private static String asJson(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}


