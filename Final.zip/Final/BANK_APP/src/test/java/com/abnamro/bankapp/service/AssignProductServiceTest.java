package com.abnamro.bankapp.service;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
public class AssignProductServiceTest {
    @MockBean
    AssignProductService assignProductService;


    @Test
    void testAssignProduct(){
        Customer customer = getCustomer();
        CustomerOwnedProducts customerOwnedProducts = getCustomerOwnedProducts();

        assignProductService.assignProduct(1, customer);

        assertEquals(1, customerOwnedProducts.getCpId());
    }
    private CustomerOwnedProducts getCustomerOwnedProducts()
    {
        CustomerOwnedProducts customerOwnedProducts= new CustomerOwnedProducts();
        customerOwnedProducts.setCpId(1);
        customerOwnedProducts.setProductId(11);
        customerOwnedProducts.setCustomerId(1);
        customerOwnedProducts.setProductName("Savings Account");
        customerOwnedProducts.setStatus(true);
        return customerOwnedProducts;
    }
    private Customer getCustomer(){
        Customer customer= new Customer();
        customer.setCustomerId(1);
        customer.setName("Nikhil Teja Akena");
        customer.setIncome(20000);
        customer.setAge(23);
        customer.setEmail("nikhilakena@gmail.com");
        customer.setMobileNumber("9848113318");
        customer.setAddress("Khammam, Hyderbad");
        return customer;
    }
}
