package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
@AutoConfigureMockMvc
public class UpdateAssignedProductStatusTest {
    @MockBean
    private UpdateAssignedProductStatusController uap;

    @Autowired
    private MockMvc mvc;
    @Test
    void testUpdateAssignedProduct() throws Exception {
        CustomerOwnedProducts c= getCustomerOwnedProducts();
        mvc.perform(put("/updateStatus").content(asJson(c)).contentType(APPLICATION_JSON)).andExpect(status().isOk()).andReturn();


    }

    private CustomerOwnedProducts getCustomerOwnedProducts()
        {
        CustomerOwnedProducts customerOwnedProducts= new CustomerOwnedProducts();
        customerOwnedProducts.setCpId(1);
        customerOwnedProducts.setProductId(11);
        customerOwnedProducts.setCustomerId(1);
        customerOwnedProducts.setProductName("Savings Account");
        customerOwnedProducts.setStatus(true);
          return customerOwnedProducts;
    }


    private static String asJson(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
