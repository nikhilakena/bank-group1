package com.abnamro.bankapp.service;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
public class UpdateAssignedProductStatusTest {
@MockBean
UpdateAssignedProductStatusService updateAssignedProductStatusService;

@Test
void testUpdateAssignedProductStatus(){
    CustomerOwnedProducts customerOwnedProducts=getCustomerOwnedProducts();
    customerOwnedProducts.setStatus(false);
    updateAssignedProductStatusService.updateStatus(1,customerOwnedProducts);
    assertEquals(false,customerOwnedProducts.isStatus());

}
    private CustomerOwnedProducts getCustomerOwnedProducts()
    {
        CustomerOwnedProducts customerOwnedProducts= new CustomerOwnedProducts();
        customerOwnedProducts.setCpId(1);
        customerOwnedProducts.setProductId(11);
        customerOwnedProducts.setCustomerId(1);
        customerOwnedProducts.setProductName("Savings Account");
        customerOwnedProducts.setStatus(true);
        return customerOwnedProducts;
    }
}
