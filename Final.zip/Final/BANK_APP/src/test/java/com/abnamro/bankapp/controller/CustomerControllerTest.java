package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {

  @InjectMocks
  CustomerController customerController;

  @Mock
  CustomerService customerService;

  Customer customer;
  List<Customer> customerList=new ArrayList<>();

  @BeforeEach
  public void setUp(){
    customer=new Customer();
    customer.setCustomerId(1);
    customer.setName("Aisha");
    customer.setAge(32);
    customer.setAddress("Thane");
    customer.setIncome(900000);
    customerList.add(customer);
      }

  @Test
  void test_getCustomerById(){
    when(customerService.getCustomerById(anyInt())).thenReturn(customer);
    ResponseEntity<Customer> customer=customerController.getCustomerById(1);
    assertEquals(1,customer.getBody().getCustomerId());
  }
@Test
  void test_getCustomerByLocation(){
  when(customerService.getCustomerByLocation(anyString())).thenReturn(customerList);
  ResponseEntity<List<Customer>> customers=customerController.getCustomerByLocation("Thane");
  assertNotNull(customer);
  assertEquals("Thane",customers.getBody().get(0).getAddress());
}

  @Test
  void test_getTop5CustomerByIncome(){
    customer=new Customer("Aisha",34,34000,"Dehradun");
    customerList.add(customer);
    customer=new Customer("Rahul",36,36000,"Thane");
    customerList.add(customer);
    customer=new Customer("Piyush",36,36000,"Bangalore");
    customerList.add(customer);
    customer=new Customer("Ram",40,40000,"Chennai");
    customerList.add(customer);
    when(customerService.getTop5CustomerByIncome()).thenReturn(customerList);
    ResponseEntity<List<Customer>> customers= (ResponseEntity<List<Customer>>) customerController.getTop5CustomerByIncome();
    assertNotNull(customers);
    assertEquals(5,customers.getBody().size());

  }
}
