package com.abnamro.bankapp.service;

import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

  @InjectMocks
  private CustomerService customerService;

  @Mock
  private CustomerRepository customerRepository;

  Customer customer;
  List<Customer> customerList=new ArrayList<>();

  @BeforeEach
  public void setUp(){
    customer=new Customer();
    customer.setCustomerId(1);
    customer.setName("Aisha");
    customer.setAge(32);
    customer.setAddress("Thane");
    customer.setIncome(90000);
    customerList.add(customer);
  }
@Test
void testCreateCustomer(){
    customerService.saveCustomer(customer);
  assertEquals(1,customer.getCustomerId());

}

  @Test
  void getCustomerById() {
    when(customerRepository.findById(anyInt())).thenReturn(Optional.ofNullable(customer));
    Customer customer=customerService.getCustomerById(1);
    assertEquals(1,customer.getCustomerId());

  }

  @Test
  void getCustomerByLocation() {
    when(customerRepository.findAll()).thenReturn(customerList);
    List<Customer> customer=customerService.getCustomerByLocation("Thane");
    assertNotNull(customer);
    assertEquals("Thane",customer.get(0).getAddress());
  }

  @Test
  void getTop5CustomerByIncome() {
    customer=new Customer("Aisha",34,34000,"Dehradun");
    customerList.add(customer);
    customer=new Customer("Rahul",36,36000,"Thane Mumbai");
    customerList.add(customer);
    customer=new Customer("Piyush",36,36000,"Bangalore");
    customerList.add(customer);
    customer=new Customer("Ram",40,40000,"Chennai");
    customerList.add(customer);
    customer=new Customer("Rama",40,40000,"Chennai");
    customerList.add(customer);
    customer=new Customer("Krishna",40,900000,"Chennai");
    customerList.add(customer);
    when(customerRepository.findAll()).thenReturn(customerList);
    List<Customer> customer=customerService.getTop5CustomerByIncome();
    assertNotNull(customer);
    assertEquals(5,customer.size());
  }
}