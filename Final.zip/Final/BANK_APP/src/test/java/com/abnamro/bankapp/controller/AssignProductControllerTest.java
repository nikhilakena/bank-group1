package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.service.AssignProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)

@SpringBootTest(classes = BankAppApplication.class)
@AutoConfigureMockMvc
public class AssignProductControllerTest {
  @MockBean
   AssignProductController assignProductController;
    @Autowired
    private MockMvc mvc;


   // @BeforeEach

   @Test
   void assignProduct() throws Exception {
       Customer customer = getCustomer();
       mvc.perform(put("/bank/assignProduct" + customer.getCustomerId()).content(asJson(customer)).contentType(APPLICATION_JSON)).andExpect(status().isOk()).andReturn();


   }
    private Customer getCustomer(){
        Customer customer= new Customer();
        customer.setCustomerId(1);
        customer.setName("Nikhil Teja Akena");
        customer.setIncome(20000);
        customer.setAge(23);
        customer.setEmail("nikhilakena@gmail.com");
        customer.setMobileNumber("9848113318");
        customer.setAddress("Khammam, Hyderbad");
        return customer;

    }
    private static String asJson(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
