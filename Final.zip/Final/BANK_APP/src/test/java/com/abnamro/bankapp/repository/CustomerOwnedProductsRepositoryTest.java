package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
/*import com.abnamro.bankapp.service.UpdateAssignedProductStatus;*/
import com.abnamro.bankapp.service.UpdateAssignedProductStatusService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import javax.transaction.Transactional;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest(classes = BankAppApplication.class)
public class CustomerOwnedProductsRepositoryTest {

    @Autowired
    private CustomerOwnedProductsRepository cop;



    @Test
    void updateAssignedProductStatus(){
        CustomerOwnedProducts customerOwnedProducts = getCustomerOwnedProducts();
        cop.save(customerOwnedProducts);
        customerOwnedProducts.setStatus(false);
        cop.save(customerOwnedProducts);
        cop.updateStatus(false, LocalDate.now(), 11, 1);
        assertEquals(false, customerOwnedProducts.isStatus());



    }

    private CustomerOwnedProducts getCustomerOwnedProducts()
    {
        CustomerOwnedProducts customerOwnedProducts= new CustomerOwnedProducts();
        customerOwnedProducts.setCpId(1);
        customerOwnedProducts.setProductId(11);
        customerOwnedProducts.setCustomerId(1);
        customerOwnedProducts.setProductName("Savings Account");
        customerOwnedProducts.setStatus(true);
        return customerOwnedProducts;
    }
}
