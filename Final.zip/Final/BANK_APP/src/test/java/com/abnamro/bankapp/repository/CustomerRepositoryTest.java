package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.BankAppApplication;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.Product;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.transaction.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@Transactional
@SpringBootTest(classes = BankAppApplication.class)
public class CustomerRepositoryTest {
    @Autowired
    CustomerRepository customerRepository;
    @Test
    void testAddCustomer(){
        //Product product1 =getProduct();
Customer customer=getCustomer();
       customerRepository.save(customer);
      Customer found= customerRepository.findById(customer.getCustomerId()).get();
        assertEquals(customer.getCustomerId(),found.getCustomerId());

    }
    private Customer getCustomer(){
        Customer customer= new Customer();
        customer.setCustomerId(1);
        customer.setName("Nikhil Teja Akena");
        customer.setIncome(20000);
        customer.setAge(23);
        customer.setEmail("nikhilakena@gmail.com");
        customer.setMobileNumber("9848113318");
        customer.setAddress("Khammam, Hyderbad");
         return customer;
    }
}
