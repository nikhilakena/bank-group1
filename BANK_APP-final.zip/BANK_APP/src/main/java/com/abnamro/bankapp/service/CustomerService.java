package com.abnamro.bankapp.service;

import com.abnamro.bankapp.dto.AssignProductDTO;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgConfigPropertyType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;

    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

   public void assignProductvalues(Integer customerId, CustomerOwnedProducts c) {


        int productId = 0;
       int custId=0;
      //  for (CustomerOwnedProducts c : customerOwnedProductsList) {
            productId = c.getProductId();
        //    custId=c.getCustomerId();
            custId=customerId;
            Product product1 = productRepository.findById(productId).get();
            Customer customer = customerRepository.findById(custId).get();
           // Product product1 = product.get();
            c.setName(product1.getName());
            c.setStartDate(product1.getStartDate());
            c.setEndDate(product1.getEndDate());
            c.setStatus(product1.getStatus());
          //  c.setCustomers(customer);
          // c.setCustomerId(customer.getCustomerId());
            c.setCustomerName(customer.getName());
            c.setCustomerId(customer.getCustomerId());
            c.setProduct(product1);
           // customer.setCustomerOwnedProducts(Collections.singletonList(c));

      //  }
    }

    public void assignCustomerValues(Integer customerId) {
        Customer customer = customerRepository.findById(customerId).get();

        CustomerOwnedProducts c = null;
        c.setCustomerId(customer.getCustomerId());
        c.setCustomerName(customer.getName());

    }

public ResponseEntity<HttpStatus> assignProduct(int customerId, Customer customer){

    Customer customer1 = customerRepository.findById(customerId).get();
    int a = customer1.getAge();
        System.out.println(a);
                int b = customer1.getIncome();
                System.out.println(b);
                if ((a) > 30 && (b) > 3000) {
                int productId;
                List<CustomerOwnedProducts> c1=customer.getCustomerOwnedProducts();
        int i;
        for (i=0;i<c1.size();i++) {
        CustomerOwnedProducts c= c1.get(i);
        System.out.println("printing   cccccc"+c);
        System.out.println("test1111");
        productId = c.getProductId();
        CustomerOwnedProducts c2 =null;
        try {
        c2 = repo.findbyCustIdAndProductId(customerId,productId);
        System.out.println(c2);
        }catch(NoSuchElementException x){
        System.out.println(x);

        }
        if(c2==null) {
        //logger.info("testing");
        System.out.println("-----------------aaaaaaaa");
        // List<CustomerOwnedProducts> cop=  customer.getCustomerOwnedProducts();
        //  for(CustomerOwnedProducts cop1 : cop)

        assignProductvalues(customerId, c);
        //customerService.assignCustomerValues(customerId);

        Customer customer2 = customerRepository.findById(customerId).get();
        List<CustomerOwnedProducts> co  =new ArrayList<>(Arrays.asList(c));


       customer1.setCustomerOwnedProducts(co);

        customerRepository.save(customer2);
        //return customer2;
        //customer1.assignProduct1(customer);
        //repo.save(customerOwnedProducts);
        //return new ResponseEntity<>(HttpStatus.OK);
        } else{
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        }
        return new ResponseEntity<>(HttpStatus.OK);
        } else {
        //logger.info("error");
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        }
        }


}
/*
    public AssignProductDTO assignProduct(AssignProductDTO assignProductDTO){

        assignProductDTO.getCustomerOwnedProductsList().stream().forEach(x->up);
    }
private void updateProductListDetails(CustomerOwnedProducts x){
        Product product= productRepository.findById(x.getProduct())
}*/



