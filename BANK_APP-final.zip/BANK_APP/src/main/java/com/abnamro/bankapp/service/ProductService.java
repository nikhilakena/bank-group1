package com.abnamro.bankapp.service;

import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public Product getProductbyId(Integer id) {
        return productRepository.findById(id).get();
    }


    public void deleteProductbyId(Integer id, Product product) {
       Product product1= productRepository.findById(id).get();
      // return productRepository.save(product1);
        product1.setStatus(product.getStatus());
        productRepository.save(product1);



    }
}