package com.abnamro.bankapp.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
public class CustomerOwnedProducts {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
private int idd;
    private int productId;
    private int customerIdd;
    private String customerName;
    private String name;
    @JsonFormat(pattern="dd/MM/yyyy")
    private Date startDate;
    @JsonFormat(pattern="dd/MM/yyyy")
    private Date endDate;
    private boolean status;
 /*   @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id", referencedColumnName = "id")
private Customer customers ;*/

 @ManyToOne (cascade= CascadeType.ALL, targetEntity = Product.class)
 @JoinColumn(name = "P_id", referencedColumnName = "productId")

         private Product product;


    public CustomerOwnedProducts() {
    }

    public CustomerOwnedProducts( int productId, int customerIdd, String customerName, String name, Date startDate, Date endDate, boolean status) {

        this.productId = productId;
        this.customerIdd = customerIdd;
        this.customerName = customerName;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

/*
    public List<Integer> getFproductid() {
        return fproductid;
    }

    public void setFproductid(List<Integer> fproductid) {
        this.fproductid = fproductid;
    }
*/

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getCustomerId() {
        return this.customerIdd;
    }

    public void setCustomerId(int customerId) {
        this.customerIdd = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getId() {
       return idd;
   }

 public void setId(int id) {
     this.idd = id;
 }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
