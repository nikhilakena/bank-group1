package com.abnamro.bankapp.dto;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;

import java.util.List;

public class AssignProductDTO
{

    private int customerId;
    private List<CustomerOwnedProducts> customerOwnedProductsList;

    public AssignProductDTO() {
    }

    public AssignProductDTO(int customerId, List<CustomerOwnedProducts> customerOwnedProductsList) {
        this.customerId = customerId;
        this.customerOwnedProductsList = customerOwnedProductsList;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public List<CustomerOwnedProducts> getCustomerOwnedProductsList() {
        return customerOwnedProductsList;
    }

    public void setCustomerOwnedProductsList(List<CustomerOwnedProducts> customerOwnedProductsList) {
        this.customerOwnedProductsList = customerOwnedProductsList;
    }
}
