package com.abnamro.bankapp.service;

import com.abnamro.bankapp.dto.AssignProductDTO;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.repository.ProductRepository;
import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgConfigPropertyType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;

    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public void assignProductvalues(Integer customerId,List<CustomerOwnedProducts> customerOwnedProductsList) {

        int productId = 0;
       int custId=0;
        for (CustomerOwnedProducts c : customerOwnedProductsList) {
            productId = c.getProductId();
        //    custId=c.getCustomerId();
            custId=customerId;
            Product product1 = productRepository.findById(productId).get();
            Customer customer = customerRepository.findById(custId).get();
           // Product product1 = product.get();
            c.setName(product1.getName());
            c.setStartDate(product1.getStartDate());
            c.setEndDate(product1.getEndDate());
            c.setStatus(product1.getStatus());
          // c.setCustomerId(customer.getCustomerId());
            c.setCustomerName(customer.getName());
            c.setCustomerId(customer.getCustomerId());

        }
    }

    public void assignCustomerValues(Integer customerId) {
        Customer customer = customerRepository.findById(customerId).get();

        CustomerOwnedProducts c = null;
        c.setCustomerId(customer.getCustomerId());
        c.setCustomerName(customer.getName());

    }
}





/*
    public AssignProductDTO assignProduct(AssignProductDTO assignProductDTO){

        assignProductDTO.getCustomerOwnedProductsList().stream().forEach(x->up);
    }
private void updateProductListDetails(CustomerOwnedProducts x){
        Product product= productRepository.findById(x.getProduct())
}*/



