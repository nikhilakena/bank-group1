package com.abnamro.bankapp.model;


import javax.persistence.*;
import java.util.List;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int customerId;
    private String name;
    private int age;
    private int income;
    private String address;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, targetEntity = CustomerOwnedProducts.class)
    @JoinColumn(name = "customer_id", referencedColumnName = "customerId")
    private List<CustomerOwnedProducts> customerOwnedProducts;

    public Customer() {
    }

    public Customer( String name, int age, int income, String address, List<CustomerOwnedProducts> customerOwnedProducts) {
      //  this.customerId = customerId;
        this.name = name;
        this.age = age;
        this.income = income;
        this.address = address;
        this.customerOwnedProducts = customerOwnedProducts;
    }
public Customer(List<CustomerOwnedProducts> customerOwnedProducts)
{
    this.customerOwnedProducts = customerOwnedProducts;
}
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getIncome() {
        return income;
    }

    public void setIncome(int income) {
        this.income = income;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<CustomerOwnedProducts> getCustomerOwnedProducts() {
        return customerOwnedProducts;
    }

    public void setCustomerOwnedProducts(List<CustomerOwnedProducts> customerOwnedProducts) {
        this.customerOwnedProducts = customerOwnedProducts;
    }
}
