package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerOwnedProductsRepository extends JpaRepository<CustomerOwnedProducts,Integer> {
}
