package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.dto.AssignProductDTO;
import com.abnamro.bankapp.model.Customer;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.repository.CustomerRepository;
import com.abnamro.bankapp.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/*import static org.springframework.jdbc.core.StatementCreatorUtils.logger;*/

@RestController
@RequestMapping("/bank")
public class AssignProductController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private CustomerOwnedProductsRepository repo;
    private Logger logger = LoggerFactory.getLogger(AssignProductController.class);

    @PutMapping("/addCustomer/{customerId}")

    public ResponseEntity<HttpStatus> assignProduct(@PathVariable Integer customerId, @RequestBody Customer customer) {
        Customer customer1 = customerRepository.findById(customerId).get();
        int a = customer1.getAge();
        System.out.println(a);
        int b = customer1.getIncome();
        System.out.println(b);
        if ((a) > 30 && (b) > 3000) {
            logger.info("testing");
            customerService.assignProductvalues(customerId, customer.getCustomerOwnedProducts());
//customerService.assignCustomerValues(customerId);

            Customer customer2 = customerRepository.findById(customerId).get();
            customer1.setCustomerOwnedProducts(customer.getCustomerOwnedProducts());
            Customer customer3 = customerRepository.save(customer2);
            //return customer2;

            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            logger.info("error");
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @PutMapping("/updateStatus/{productId}/{customerId}")

    public int updateStatus(@PathVariable int productId,@PathVariable int customerId,@RequestBody CustomerOwnedProducts c1) {
       boolean a= c1.getStatus();
        System.out.println(a);
        System.out.println("hi1111111111111111");
          int b=  repo.updateStatus(a, productId,customerId);

return b;

        }
    }
