package com.abnamro.bankapp.repository;

import com.abnamro.bankapp.model.CustomerOwnedProducts;
import org.hibernate.sql.Update;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CustomerOwnedProductsRepository extends JpaRepository<CustomerOwnedProducts,Integer> {

  @Modifying
@Transactional
   @Query("update CustomerOwnedProducts c set c.status = ?1 where c.productId= ?2 and c.customerIdd=?3")
    int updateStatus(  boolean status, int productId,int customerId);

  @Query("select t from CustomerOwnedProducts t where  t.productId =?1 and t.status=true")
  List<CustomerOwnedProducts> findByProductIdAndStatus(int productId);

}
