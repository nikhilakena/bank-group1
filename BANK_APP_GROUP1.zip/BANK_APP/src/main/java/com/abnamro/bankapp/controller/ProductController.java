package com.abnamro.bankapp.controller;

import com.abnamro.bankapp.exception.ResourceNotFound;
import com.abnamro.bankapp.model.CustomerOwnedProducts;
import com.abnamro.bankapp.model.Product;
import com.abnamro.bankapp.repository.CustomerOwnedProductsRepository;
import com.abnamro.bankapp.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/bank")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private CustomerOwnedProductsRepository customerOwnedProductsRepository;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product) {


        return productService.saveProduct(product);
    }

    @GetMapping("/getProduct/{id}")
    public Product getProductById(@PathVariable Integer id) {
        return productService.getProductbyId(id);
    }

  /*  @PutMapping("/deleteProduct/{productId}")
    public ResponseEntity<HttpStatus> deleteProductbyId(@PathVariable Integer productId, @RequestBody Product product) throws ResourceNotFound {


        List<CustomerOwnedProducts> c = null;
        try {
            c = (List<CustomerOwnedProducts>) customerOwnedProductsRepository.findById(productId).get();
        } catch (NoSuchElementException x) {
            System.out.println(x);
        }
        int a = 0;

        System.out.println(a);

        if (c == null) {
            productService.deleteProductbyId(productId, product);
            return new ResponseEntity<>(HttpStatus.OK);

        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }*/

    @PutMapping("/deleteProduct/{productId}")
    public ResponseEntity<HttpStatus> deleteProductbyId(@PathVariable Integer productId, @RequestBody Product product) throws ResourceNotFound {
List<CustomerOwnedProducts> c=null;

        try {
            System.out.println("heloo11111111111");
            c = customerOwnedProductsRepository.findByProductIdAndStatus(productId);
        } catch (NoSuchElementException x) {
            System.out.println(x);
        }


        if (c.isEmpty()) {
            productService.deleteProductbyId(productId, product);
            return new ResponseEntity<>(HttpStatus.OK);

        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

}